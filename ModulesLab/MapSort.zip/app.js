let mapSort = require('./02.MapSort');

result.mapSort = mapSort;